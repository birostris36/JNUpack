%# Contents of "toolbox/ocean/geostrophy/private"
%   
%   alpha    - function [spv,k,steran] = alpha(p,t,s)
%   dist     - Distance between geogralatcal points
%   dist2    - DIST Distance and bearing between geographical points
%   g        - Ravitational constant
%   gradnan  - Approximate gradient
%   maxnan   - MAXMISS Column maximum with missing data
%   meannan  - Column mean with missing data
%   minnan   - Column minimum with missing data
%   p2z      - function  depth=p2z(p,lat)
%   sumnan   - Sum of elements with missing data
%   svan     - Specific volume anomaly
%   
