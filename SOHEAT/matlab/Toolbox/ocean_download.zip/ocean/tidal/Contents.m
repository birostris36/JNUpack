% Tidal Analysis using SVD # Contents of "toolbox/ocean/tidal"
%   
%   tidanal      - Tidal Analysis using SingularValueDecomposition
%   tidfit       - Tidal fit using results from TIDANAL
%   tidtest      - Test and check for TIDANAL and TIDFIT
%   tidtest_fit  - Another Test for TIDANAL
%   
